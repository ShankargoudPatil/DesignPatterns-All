﻿using Microsoft.AspNetCore.Identity;

namespace HPlusSport.Web
{
    public class HPlusSportWebUser : IdentityUser
    {
    }
}
